<div class="box_left">
    <span class="center">&nbsp;</span>
    <span class="bottom">&nbsp;</span>
</div>
<div class="box_right">
    <span class="center">
        <div class="text_inner">
			<h3>Sistema de administraci&oacute;n de <b>www.tempolink.com.co</b></h3>
			<br />
            Con esta herramienta usted puede administrar los diferentes componenentes que forman
			su portal en Internet.<br />
			<br />
			Haga clic en los &iacute;tems del men&uacute; de la parte superior para acceder a los
			m&oacute;dulos de esta herramienta.
        </div>
    </span>
    <span class="bottom">&nbsp;</span>
</div>