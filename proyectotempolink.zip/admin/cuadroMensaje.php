<div id="overlay" style="display: none;">
    <div id="mensaje">
        <table width="100%" cellspacing="10">
            <tr>
                <td><h3 id="tituloMensaje"></h3></td>
            </tr>
            <tr>
                <td><p id="textoMensaje"></p></td>
            </tr>
            <tr>
                <td><input type="button" class="button" value="Aceptar" id="aceptarMensaje"/></td>
            </tr>
        </table>
    </div>
</div>