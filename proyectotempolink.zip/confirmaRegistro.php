<h3>Registro exitoso</h3>
<div class="homeText">
	Apreciado(a) Usuario<br /><br />
    Usted ya se encuentra registrado en nuestra base de datos, en los proximos dias recibira un correo de Bienvenida y aceptaci&oacute;n.<br /><br />
    Si tiene alguna duda puede contactarnos <a href="index.php?pag=contacto">aqu&iacute;</a>.
</div>