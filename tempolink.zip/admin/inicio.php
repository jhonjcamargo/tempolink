<div class="box_left">
    <span class="center">&nbsp;</span>
    <span class="bottom">&nbsp;</span>
</div>
<div class="box_right">
    <span class="center">
        <div class="text_inner">
			<h3>Sistema de consulta TempoLink</h3>
			<br />
            Por medio de este sistema usted podra encontrar las diferentes secciones dependiendo su perfil.
        </div>
    </span>
    <span class="bottom">&nbsp;</span>
</div>