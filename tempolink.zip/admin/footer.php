<div class="footer_left">
    <strong>&copy; Copyright <?php echo( date("Y") ); ?></strong> Agatha Group| Bogot&aacute; - Colombia.<br />
    Carrera 4a Nro 26 - 42 Ofc 102. | PBX: (051) 562 2888 o escribanos a <a href="mailto:contacto@agathagroup.com">contacto@agathagroup.com</a>
</div>
