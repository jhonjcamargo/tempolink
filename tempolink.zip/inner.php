<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>::. TEMPO LINK - INNER .::</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="header">
    <div class="wrapper">
    	<h1 id="logo">
        	<a href="www.google.com"></a>
        </h1>
        <div id="navTop">
        	<ul class="registro">
            	<li><a href="">Registrarse</a></li>
                <li><a href="" class="cuenta">Mi cuenta</a></li>
            </ul>
        </div>
        <ul id="menu">
        	<li><a href="" class="select">Inicio</a></li>
            <li><a href="">Quienes Somos</a></li>
            <li><a href="">Productos y servicios</a></li>
            <li><a href="">Empresas</a></li>
            <li><a href="">Personas</a></li>
            <li><a href="">Tempolink VIP</a></li>
            <li><a href="">Cont&aacute;ctenos</a></li>
        </ul>
        <ul id="socialTop">
        	<li><a href=""><img src="images/in.png" /></a></li>
            <li><a href=""><img src="images/fcbk.png" /></a></li>
            <li><a href=""><img src="images/tw.png" /></a></li>
            <li><a href=""><img src="images/bd.png" /></a></li>
        </ul>
        <div id="banner">
        	<img src="images/banner.png" />
        </div>
        <ul class="tabsPasos">
            <li><a href=""><img src="images/registrate.png" /></a></li>
            <li><a href=""><img src="images/carga.png" /></a></li>
            <li class="post"><a href=""><img src="images/postulate.png" /></a></li>
        </ul>
    </div>
</div>
<div id="main">
    <div id="contenido">
        <div class="cajas">
            <div class="cajaTexto">
                <h3>Qui&eacute;nes Somos</h3>
                <div class="homeText">
                    <p>asdasdsa asdasdasdsa dsa d asdsadsadsad sad sa dsadsadsad asdsadsadsa dsa dsadsadsadsa<br />
                    asdasdsa asdasdasdsa dsa d asdsadsadsad sad sa dsadsadsad asdsadsadsa dsa dsadsadsadsa asdasdsa asdasdasdsa dsa d asdsadsadsad sad sa dsadsadsad asdsadsadsa dsa dsadsadsadsa<br /></p>
                </div>
            </div>
            <div class="cajaMenu">
    			<div class="menuINav">
                	<ul id="menuInner">
                    	<li><a href="#">filosofia</a></li>
                        <li><a href="#">mision</a></li>
                        <li><a href="#">vision</a></li>
                    </ul>
                </div>         
            </div>
		</div>
    </div>
</div>
<div id="footer">
	<div id="innerfooter">
    	<ul id="footerItems">
        	<li>Bogot&aacute; Colombia</li>
            <li>Comunicate<br />(571) 600 6007</li>
        </ul>
    </div>
</div>
</body>
</html>