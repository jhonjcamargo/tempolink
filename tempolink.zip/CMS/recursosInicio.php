<h3>RECURSOS</h3><br />
En este m&oacute;dulo usted puede administrar los direfentes archivos (.jpg, .doc, .pdf, etc), que componen su portal.<br />
<br />
Seleccione el &iacute;tem del men&uacute; de la izquierda de su elecci&oacute;n.