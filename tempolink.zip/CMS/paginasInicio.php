<h3>P&Aacute;GINAS DEL PORTAL</h3><br />
En este m&oacute;dulo usted puede administrar las p&aacute;ginas que forman su portal.<br />
<br />
Usted puede elegir entre varios tipos de presentaci&oacute;n de estas p&aacute;ginas
dependiendo su necesidad.<br />
<br />
Dependiendo de su elecci&oacute;n se configura la p&aacute;gina para ingresar el
contenido del que ella se compone.
<br />
Seleccione del men&uacute; de la izquierda la opci&oacute;n de su preferencia.