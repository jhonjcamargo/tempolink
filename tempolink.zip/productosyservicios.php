<div class="prod_index">
	<div class="wrapper">
		<div class="widthwrap">
			<div class="prod_txt">
				Los siguientes son nuestros productos y servicios:
			</div>
			<div class="cont_prod">
					<div class="cont_proda">
						<a href="index.php?pag=pagina&id=6&padre=5" class="img_fond">
							<img alt="" src="/images/newimg/circ_pr.png"/>
						</a>
						<div class="img_fondo">
							<img alt="" src="/images/newimg/productosimg.png"/>
						</div>
						<h3>Productos</h3>
					</div>
					
				    <div class="cont_proda">
					<a href="index.php?pag=pagina&id=5&padre=5" class="img_fond">
						<img alt="" src="/images/newimg/circ_pr.png"/>
					</a>
					<div class="img_fondo">
						<img alt="" src="/images/newimg/HML3.png"/>
					</div>
					<h3>Servicios</h3>
				</div>
			</div>
		</div>
	</div>
</div>
