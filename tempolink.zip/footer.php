<div class="prefootera">
	<div class="wrapper">
	
		<div class="inside-prefa"> 
			<div style="margin: 0 0px 0px 15px;">
				<img alt="" src="/images/newimg/iconRH.png">
				<span>Recursos Humanos</span><br><br>
			</div>
	        Para nuestra compañia es muy importante la parte del reclutamiento para las empresas aliadas, por esta razon nos encargamos de realizar pruebas tecnicas y psicologicas para evaluar un excelente candidato. ¡No te quedes por Fuera Suscribete ahora!
	  	</div>
	    <div class="inside-prefb">
	    	<div style="margin: 0 0px 0px 15px;">
				<img alt="" src="/images/newimg/adduser.png">
	    		<span>Regístrate</span><br><br>
	    	</div>	
	    	Para que pueda acceder a nuestro portal de busqueda de empleo es necesario estar previamente registrado, para acceder a todas las propuestas ingresa al boton inferior.<br><br> 
	    	<center><a href="index.php?pag=registro" class="boton-pf">Registrarse</a></center>
	    </div>
	    <div class="inside-prefb">
	    	<div style=" margin: 0 0px 0px 15px;">
				<img alt="" src="/images/newimg/cv.png">
	    		<span>Cargar C.V</span><br><br>
	    	</div>	
	    	Al mantener actualizada su hoja de vida, tienes mas opciones de ser seleccionado, por esta razon es necesario que actualices tu informacion.
	    </div>
	    <div class="inside-prefb">
	    	<div style=" margin: 0 0px 0px 15px;">
				<img alt="" src="/images/newimg/apply.png">
	    		<span>¡Postulate!</span><br><br>
	    	</div>	
	        Para poder aplicar a las ofertas publicadas necesariamente tiene que iniciar sesión- 
		</div><br>
	</div>	
</div><!--fin prefootera-->

<!--   ************************************Footer ************************ -->
<footer>
	<div class="wrapper">
		<div class="Wddp">
			<div class="tag_f">
				<img alt="" src="images/newimg/ico_ubicacion.png" />
				<div>
					<h5>Ubicacion:</h5>
					<p class="italic">Cr 7 # 32-83 of 802 <br> Bogotá – Colombia</p>
				</div>
			</div>
			<div class="tag_f">
				<img alt="" src="images/newimg/ico_correo.png" />
				<div>
					<h5>Contacto:</h5>
					<p class="italic">PBX: (571) 744 6224<br> Mail: comercial1@tempolink.com.co</p>
				</div>
			</div>

			<img class="imgicontec" alt="" src="images/newimg/icontec-iqnet.png" />
			<a class="logosfooter" href="#" >
			<img alt="" src="images/Tempolink_logo.png" />
			<img alt="" src="images/newimg/hmlkFinal.png" />
			</a>
		</div>
	</div>


<!-- <div class="footer-txt">
    	<p style="color: #858585; font-weight: normal; font-size: 16px; width: 340px;">Contacto: comercial1@tempolink.com.co</p>
        <p style="margin: 6px 0 0; font-size: 12px; color: #666;"> Todos los derechos reservados TEMPOLINK & HUMAN LINK.</p>
    </div>   
    <div class="footer-icons">
	    <a href="index.html" >
	    	<img src="images/twitter-gray.png" class="icons" width="48" height="48">
	    </a>
	    <div class="icons">
	    	<a href="index.html">
	    		<img src="images/facebook-gray.png" width="48" height="48">
	    	</a>
	    </div>
	    <div class="logos" style="  width: 143px; height: 34px; float: right; margin: 18px 8px;">
		    <a href="index.html" >
		    	<img src="images/newimg/LOGO-HUMAN-LINK.png">
		    </a>
	    </div>
    </div> -->	

</footer>

<!-- <div id="footer">
	<div id="innerfooter">
    	<ul id="footerItems">
        	<li>Bogot&aacute; Colombia</li>
            <li>Comunicate<br />(+571) 7446224</li>
           	<p>Todos los derechos reservados Tempolink 2015</p>
        </ul>
		<div id="logos-footer">
			<img src="images/logo-footer.png" />
			<img src="images/logo-icontect.png"  />
		</div>
    </div>
</div> 
<div class="footer">
	<div class="footer_bottom">
		<a><img class="logoSmall" src="images/Tempolink_logo.png" alt="Tempolink" /></a>
		<p><strong>Dirección:</strong> Cra. 47 # 124 - 47<br><strong>Correo:</strong> admin@tempolink.com<br>Bogotá<br>
			<strong>Todos los derechos reservados Tempolink 2015</strong></p>
		<a class="otrologo"><img src="images/LOGO-HUMAN-LINK.png" alt="" /></a>
		<!-- <a class="otrologo"><img src="images/logo-icontect.png" alt="" /></a> 
	</div>
</div>-->
